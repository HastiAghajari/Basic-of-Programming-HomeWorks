﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace SQLDATABASE
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        string id;
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string Mobile = textBox1.Text();
                string Username = textBox2.Text();
                int Dateofbirth = textBox3.Text();
                String selected = comboBox1.SelectedItem.ToString();
                string sp = selected.Split('-')[0];
                id = sp;
                string query = $"SELECT * FROM dbo WHERE id='{sp}'";
                string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\MRC\source\repos\SQLDATABASE\SQLDATABASE\Database1.mdf;Integrated Security=True";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();
                reader.Read();
                textBox1.Text = reader["Mobile"].ToString();
                textBox2.Text = reader["Username"].ToString();
                textBox3.Text = reader["Dateofbirth"].ToString();
                button1.Text = "Update";

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                String selected = comboBox1.SelectedItem.ToString();
                string sp = selected.Split('-')[0];
                string query = $"DELETE FROM dbo WHERE id='{sp}'";
                string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\MRC\source\repos\SQLDATABASE\SQLDATABASE\Database1.mdf;Integrated Security=True";
                SqlConnection connection = new SqlConnection(connectionString);

                connection.Open();

                SqlCommand command = new SqlCommand(query, connection);

                if (command.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Delete Data Successfully.");
                    refresh();
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void refresh()
        {
            try
            {
                comboBox1.Items.Clear();
                string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\gheir\source\repos\WindowsFormsApp48\WindowsFormsApp48\Database1.mdf;Integrated Security=True";
                SqlConnection connection = new SqlConnection(connectionString);
                string query = "SELECT id, name FROM Students";
                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string opt = reader["id"].ToString() + "-" + reader["Name"].ToString();
                    comboBox1.Items.Add(opt);
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Database1 (Firstname,Lastname) VALUES " +
    "('" + Mobile + "','" + Username + "','" + Dateofbirth + "')";

            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\MRC\source\repos\SQLDATABASE\SQLDATABASE\Database1.mdf;Integrated Security=True";
            SqlConnection connection = (SqlConnection)new SqlConnection(connectionString);

            connection.Open();

            SqlCommand command = new SqlCommand(query, connection);
            try
            {
                string Mobile = textBox1.Text();
                string Username = textBox2.Text();
                int Dateofbirth = textBox3.Text();
                string query = $"UPDATE Students SET Mobile='{Mobile}', Username='{Username}', Dateofbirth='{Dateofbirth}' WHERE id='{id}'";
                string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\gheir\source\repos\WindowsFormsApp48\WindowsFormsApp48\Database1.mdf;Integrated Security=True";
                SqlConnection connection = new SqlConnection(connectionString);

                connection.Open();

                SqlCommand command = new SqlCommand(query, connection);

                if (command.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Update Data Successfully.");
                    textBox1.Text = textBox2.Text = textBox3.Text = "";
                    button1.Text = "Insert";
                    id = "";
                    refresh();
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
}
