
using System.Data.SqlClient;

namespace SQLDATABASE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
                try
                { 
                    string Firstname = textBox1.Text;
                    string Lastname = textBox2.Text;
                    string query = "INSERT INTO Database1 (Firstname,Lastname) VALUES " +
                        "('" + Firstname + "','" + Lastname + "')";

                    string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\MRC\source\repos\SQLDATABASE\SQLDATABASE\Database1.mdf;Integrated Security=True";
                    SqlConnection connection = (SqlConnection)new SqlConnection(connectionString);

                    connection.Open();

                    SqlCommand command = new SqlCommand(query, connection);

                    if (command.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Insert Data Successfully.");
                        Form2 form2 = new Form2();
                        form2.Show();
                    }
                    connection.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
